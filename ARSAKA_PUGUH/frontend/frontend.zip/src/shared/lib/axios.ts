/**
 * Axios HTTP Client Configuration
 * Phase A+ - Minimal setup for visibility
 */

import axios from 'axios'

// Base URL from environment or default to backend API
const baseURL = import.meta.env.VITE_API_BASE_URL || 'http://31.97.111.175:30934'

export const apiClient = axios.create({
  baseURL,
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 30000, // 30 seconds
})

// Request interceptor - add auth token if exists
apiClient.interceptors.request.use(
  (config) => {
    // Mock token for Phase A+ (no real auth)
    const token = localStorage.getItem('auth_token')
    if (token) {
      config.headers.Authorization = `Bearer ${token}`
    }
    return config
  },
  (error) => Promise.reject(error)
)

// Response interceptor - handle errors
apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response) {
      // Server responded with error status
      console.error('API Error:', error.response.status, error.response.data)
    } else if (error.request) {
      // Request made but no response
      console.error('Network Error:', error.message)
    } else {
      // Something else happened
      console.error('Error:', error.message)
    }
    return Promise.reject(error)
  }
)
