/**
 * Domain Layout - Phase 4
 * Main layout with 5-domain navigation
 */

import { NavLink, Outlet, useLocation } from 'react-router-dom'
import {
  Users,
  Building2,
  Scale,
  CheckCircle,
  BarChart3,
  Menu,
  X,
  LayoutDashboard,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { useState } from 'react'

interface DomainConfig {
  name: string
  path: string
  icon: React.ElementType
  color: string
  bgColor: string
  description: string
}

const domains: DomainConfig[] = [
  {
    name: 'IAM',
    path: '/iam',
    icon: Users,
    color: 'text-iam',
    bgColor: 'bg-iam',
    description: 'Identity & Access',
  },
  {
    name: 'Tenant',
    path: '/tenant',
    icon: Building2,
    color: 'text-tenant',
    bgColor: 'bg-tenant',
    description: 'Tenant Isolation',
  },
  {
    name: 'Decision',
    path: '/decision',
    icon: Scale,
    color: 'text-decision',
    bgColor: 'bg-decision',
    description: 'Rules & Policy',
  },
  {
    name: 'Workflow',
    path: '/workflow',
    icon: CheckCircle,
    color: 'text-workflow',
    bgColor: 'bg-workflow',
    description: 'Approvals',
  },
  {
    name: 'Control',
    path: '/control',
    icon: BarChart3,
    color: 'text-control',
    bgColor: 'bg-control',
    description: 'Audit & Metrics',
  },
]

function getDomainFromPath(pathname: string): DomainConfig | undefined {
  return domains.find(d => pathname.startsWith(d.path))
}

export function DomainLayout() {
  const location = useLocation()
  const currentDomain = getDomainFromPath(location.pathname)
  const [sidebarOpen, setSidebarOpen] = useState(false)

  return (
    <div className="min-h-screen bg-background">
      {/* Top Header */}
      <header className={cn(
        "sticky top-0 z-40 border-b transition-colors",
        currentDomain ? currentDomain.bgColor : "bg-primary"
      )}>
        <div className="flex h-14 items-center px-4 gap-4">
          {/* Mobile menu button */}
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="lg:hidden text-white p-2 hover:bg-white/10 rounded"
          >
            {sidebarOpen ? <X size={20} /> : <Menu size={20} />}
          </button>

          {/* Logo */}
          <div className="flex items-center gap-2 text-white">
            <span className="font-bold text-lg">ATLAS_PUGUH</span>
            <span className="text-white/70 text-sm hidden sm:inline">Phase 4 CMS</span>
          </div>

          {/* Current Domain Badge */}
          {currentDomain && (
            <div className="ml-auto flex items-center gap-2 text-white">
              <currentDomain.icon size={18} />
              <span className="font-medium">{currentDomain.name}</span>
              <span className="text-white/70 text-sm hidden md:inline">
                {currentDomain.description}
              </span>
            </div>
          )}
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside className={cn(
          "fixed inset-y-0 left-0 z-30 w-64 transform bg-card border-r pt-14 transition-transform lg:translate-x-0 lg:static lg:pt-0",
          sidebarOpen ? "translate-x-0" : "-translate-x-full"
        )}>
          <nav className="p-4 space-y-1">
            {/* Dashboard Link */}
            <NavLink
              to="/"
              end
              onClick={() => setSidebarOpen(false)}
              className={({ isActive }) => cn(
                "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors mb-4",
                isActive
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
              )}
            >
              <LayoutDashboard size={18} />
              <div className="flex flex-col">
                <span>Dashboard</span>
                <span className="text-xs opacity-70">Overview</span>
              </div>
            </NavLink>

            <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-4 px-3">
              Domains
            </div>
            {domains.map((domain) => (
              <NavLink
                key={domain.path}
                to={domain.path}
                onClick={() => setSidebarOpen(false)}
                className={({ isActive }) => cn(
                  "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors",
                  isActive
                    ? cn(domain.bgColor, "text-white")
                    : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
                )}
              >
                <domain.icon size={18} />
                <div className="flex flex-col">
                  <span>{domain.name}</span>
                  <span className="text-xs opacity-70">{domain.description}</span>
                </div>
              </NavLink>
            ))}
          </nav>

          {/* Phase Warning */}
          <div className="absolute bottom-0 left-0 right-0 p-4 border-t bg-yellow-50">
            <div className="text-xs text-yellow-800">
              <strong>Phase 4</strong>
              <p className="mt-1">UI is operational layer only. All enforcement via SDK → Core API.</p>
            </div>
          </div>
        </aside>

        {/* Overlay for mobile */}
        {sidebarOpen && (
          <div
            className="fixed inset-0 z-20 bg-black/50 lg:hidden"
            onClick={() => setSidebarOpen(false)}
          />
        )}

        {/* Main Content */}
        <main className="flex-1 p-6 lg:p-8">
          <Outlet />
        </main>
      </div>
    </div>
  )
}
