/**
 * Health Reporter Module
 * Collects and reports device health metrics to backend
 *
 * Reports every 5 minutes:
 * - System: CPU, Memory, Disk usage
 * - Network: Latency, bandwidth, connection quality
 * - Display: Resolution, refresh rate
 * - Player: Version, uptime, error counts
 */

window.HealthReporter = {
    intervalId: null,
    reportInterval: 5 * 60 * 1000, // 5 minutes
    isRunning: false,
    startTime: Date.now(),
    errorCount: 0,
    lastError: null,

    /**
     * Start health monitoring
     */
    start: function() {
        if (this.isRunning) {
            SharedLogger.log('[HealthReporter] Already running');
            return;
        }

        // Get device from state
        const device = window.SharedDeviceState ? window.SharedDeviceState.getDevice() : null;
        if (!device || !device.id) {
            SharedLogger.error('[HealthReporter] No device ID, cannot start health monitoring');
            return;
        }

        SharedLogger.log('[HealthReporter] 🏥 Starting health monitoring...');
        this.isRunning = true;
        this.startTime = Date.now();

        // Report immediately on start
        this.reportHealth();

        // Schedule periodic reports
        this.intervalId = setInterval(() => {
            this.reportHealth();
        }, this.reportInterval);

        SharedLogger.log(`[HealthReporter] ✅ Health monitoring started (reports every ${this.reportInterval / 60000} minutes)`);
    },

    /**
     * Stop health monitoring
     */
    stop: function() {
        if (this.intervalId) {
            clearInterval(this.intervalId);
            this.intervalId = null;
        }
        this.isRunning = false;
        SharedLogger.log('[HealthReporter] ⏹️ Health monitoring stopped');
    },

    /**
     * Report health metrics to backend
     */
    reportHealth: async function() {
        const device = window.SharedDeviceState ? window.SharedDeviceState.getDevice() : null;
        if (!device || !device.id) {
            SharedLogger.error('[HealthReporter] No device ID, skip health report');
            return;
        }

        try {
            SharedLogger.log('[HealthReporter] 📊 Collecting health metrics...');

            // Collect all metrics
            const metrics = await this.collectMetrics();

            // Get API base URL
            const apiBaseUrl = window.Config?.API_BASE_URL || window.SharedENV?.API_BASE_URL;
            if (!apiBaseUrl) {
                SharedLogger.error('[HealthReporter] No API_BASE_URL configured');
                return;
            }

            // Send to backend
            const url = `${apiBaseUrl}/api/v1/devices/${device.id}/health`;

            const response = await fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(metrics)
            });

            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }

            const result = await response.json();
            SharedLogger.log('[HealthReporter] ✅ Health metrics reported successfully', result);

        } catch (error) {
            this.errorCount++;
            this.lastError = {
                message: error.message,
                timestamp: new Date().toISOString()
            };
            SharedLogger.error('[HealthReporter] ❌ Failed to report health:', error);
        }
    },

    /**
     * Collect all health metrics
     */
    collectMetrics: async function() {
        const metrics = {
            // System metrics
            cpu_usage: await this.getCPUUsage(),
            memory_usage: await this.getMemoryUsage(),
            memory_total_mb: await this.getMemoryTotal(),
            memory_used_mb: await this.getMemoryUsed(),
            disk_usage: await this.getDiskUsage(),
            disk_total_gb: await this.getDiskTotal(),
            disk_used_gb: await this.getDiskUsed(),

            // Network metrics
            network_latency_ms: await this.measureLatency(),
            network_download_mbps: await this.getDownloadSpeed(),
            network_upload_mbps: await this.getUploadSpeed(),
            connection_quality: await this.getConnectionQuality(),

            // Display metrics
            display_resolution: this.getDisplayResolution(),
            display_refresh_rate: this.getRefreshRate(),
            gpu_usage: await this.getGPUUsage(),

            // Player metrics
            player_version: this.getPlayerVersion(),
            player_uptime_hours: this.getUptimeHours(),
            content_errors_count: this.errorCount,
            last_error_message: this.lastError ? this.lastError.message : null,
            last_error_at: this.lastError ? this.lastError.timestamp : null,

            // Additional metadata
            metadata: {
                user_agent: navigator.userAgent,
                platform: window.ShellHeartbeat ? window.ShellHeartbeat.detectPlatform() : 'Unknown',
                online: navigator.onLine,
                timestamp: new Date().toISOString()
            }
        };

        return metrics;
    },

    /**
     * Estimate CPU usage
     * Browser doesn't have direct CPU access, so we estimate based on performance
     */
    getCPUUsage: async function() {
        try {
            const start = performance.now();
            let sum = 0;

            // CPU-intensive operation
            for (let i = 0; i < 1000000; i++) {
                sum += Math.sqrt(i);
            }

            const duration = performance.now() - start;

            // Estimate: faster = lower CPU usage, slower = higher CPU usage
            // Baseline: ~10ms on modern CPU = 10% usage
            const estimatedUsage = Math.min(100, (duration / 10) * 10);

            return Math.round(estimatedUsage * 100) / 100; // Round to 2 decimals
        } catch (error) {
            SharedLogger.error('[HealthReporter] Failed to get CPU usage:', error);
            return null;
        }
    },

    /**
     * Get memory usage percentage
     */
    getMemoryUsage: async function() {
        try {
            if ('memory' in performance) {
                const mem = performance.memory;
                const usage = (mem.usedJSHeapSize / mem.jsHeapSizeLimit) * 100;
                return Math.round(usage * 100) / 100;
            }
            return null;
        } catch (error) {
            return null;
        }
    },

    /**
     * Get total memory in MB
     */
    getMemoryTotal: async function() {
        try {
            if ('memory' in performance) {
                const mem = performance.memory;
                return Math.round(mem.jsHeapSizeLimit / (1024 * 1024));
            }
            return null;
        } catch (error) {
            return null;
        }
    },

    /**
     * Get used memory in MB
     */
    getMemoryUsed: async function() {
        try {
            if ('memory' in performance) {
                const mem = performance.memory;
                return Math.round(mem.usedJSHeapSize / (1024 * 1024));
            }
            return null;
        } catch (error) {
            return null;
        }
    },

    /**
     * Get disk usage percentage
     */
    getDiskUsage: async function() {
        try {
            if ('storage' in navigator && 'estimate' in navigator.storage) {
                const estimate = await navigator.storage.estimate();
                const usage = (estimate.usage / estimate.quota) * 100;
                return Math.round(usage * 100) / 100;
            }
            return null;
        } catch (error) {
            return null;
        }
    },

    /**
     * Get total disk space in GB
     */
    getDiskTotal: async function() {
        try {
            if ('storage' in navigator && 'estimate' in navigator.storage) {
                const estimate = await navigator.storage.estimate();
                return Math.round(estimate.quota / (1024 * 1024 * 1024));
            }
            return null;
        } catch (error) {
            return null;
        }
    },

    /**
     * Get used disk space in GB
     */
    getDiskUsed: async function() {
        try {
            if ('storage' in navigator && 'estimate' in navigator.storage) {
                const estimate = await navigator.storage.estimate();
                return Math.round(estimate.usage / (1024 * 1024 * 1024) * 100) / 100;
            }
            return null;
        } catch (error) {
            return null;
        }
    },

    /**
     * Measure network latency to backend
     */
    measureLatency: async function() {
        try {
            const apiBaseUrl = window.Config?.API_BASE_URL || window.SharedENV?.API_BASE_URL;
            if (!apiBaseUrl) return null;

            const start = performance.now();

            // Ping health endpoint
            await fetch(`${apiBaseUrl}/health`, {
                method: 'HEAD',
                cache: 'no-cache'
            });

            const latency = Math.round(performance.now() - start);
            return latency;
        } catch (error) {
            SharedLogger.error('[HealthReporter] Failed to measure latency:', error);
            return null;
        }
    },

    /**
     * Estimate download speed (simplified)
     */
    getDownloadSpeed: async function() {
        try {
            if ('connection' in navigator && navigator.connection.downlink) {
                return navigator.connection.downlink; // Mbps
            }
            return null;
        } catch (error) {
            return null;
        }
    },

    /**
     * Estimate upload speed (simplified)
     */
    getUploadSpeed: async function() {
        try {
            // Browser API doesn't provide upload speed
            // Estimate as 20% of download speed
            if ('connection' in navigator && navigator.connection.downlink) {
                return Math.round(navigator.connection.downlink * 0.2 * 100) / 100;
            }
            return null;
        } catch (error) {
            return null;
        }
    },

    /**
     * Determine connection quality
     */
    getConnectionQuality: async function() {
        try {
            const latency = await this.measureLatency();

            if (!latency) return 'unknown';
            if (latency < 50) return 'excellent';
            if (latency < 100) return 'good';
            if (latency < 200) return 'fair';
            if (latency < 500) return 'poor';
            return 'very_poor';
        } catch (error) {
            return 'unknown';
        }
    },

    /**
     * Get display resolution
     */
    getDisplayResolution: function() {
        return `${window.screen.width}x${window.screen.height}`;
    },

    /**
     * Get display refresh rate (estimated)
     */
    getRefreshRate: function() {
        // Most displays are 60Hz, some are 120Hz
        // We can't detect this accurately in browser
        return 60;
    },

    /**
     * Get GPU usage (not available in browser)
     */
    getGPUUsage: async function() {
        // Browser doesn't provide GPU usage
        return null;
    },

    /**
     * Get player version
     */
    getPlayerVersion: function() {
        return window.Config?.PLAYER_VERSION || '1.0.0';
    },

    /**
     * Get player uptime in hours
     */
    getUptimeHours: function() {
        const uptimeMs = Date.now() - this.startTime;
        const uptimeHours = Math.floor(uptimeMs / (1000 * 60 * 60));
        return uptimeHours;
    },

    /**
     * Record error for health metrics
     */
    recordError: function(errorMessage) {
        this.errorCount++;
        this.lastError = {
            message: errorMessage,
            timestamp: new Date().toISOString()
        };
        SharedLogger.log(`[HealthReporter] 📝 Error recorded: ${errorMessage}`);
    },

    /**
     * Reset error count
     */
    resetErrors: function() {
        this.errorCount = 0;
        this.lastError = null;
        SharedLogger.log('[HealthReporter] Error count reset');
    }
};
